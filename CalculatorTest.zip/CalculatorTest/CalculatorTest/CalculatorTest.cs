﻿using System;
using System.Linq;
using Xunit;
using TestStack.White;
using TestStack.White.Factory;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems;
using Xunit.Sdk;
using Xunit.Extensions;
using System.Collections.Generic;

namespace CalculatorTestSuite
{
    public class CalculatorTests : IDisposable
    {
        private const string CALCEXE = @"C:\Windows\System32\calc.exe";
        public static Application calcApp;
        public Window mainWindow;
        public CalculatorTests()
        {
            calcApp = Application.Launch(CALCEXE);
            CalculatorWindow mainWindow = new CalculatorWindow(calcApp.GetWindow("Calculator"));
        }
        
        public void Dispose()
        {
            calcApp.Dispose();
        }
        
        public class CalcDataSet
        {
            public string FirstValue { get; set; }
            public string Operation { get; set; }
            public string SecondValue { get; set; }
            public string ExpectedResult { get; set; }
        }

        public static IEnumerable<object[]> InputData()
        {
            return new[]
            {
                new object[]
                {
                    "Divide simple number by zero",
                    new CalcDataSet()
                    {
                        FirstValue = "6",
                        Operation = "Divide",
                        SecondValue = "3",
                        ExpectedResult = "2"
                    }
                },
                new object[]
                {
                    "Add two simple numbers",
                    new CalcDataSet()
                    {
                        FirstValue = "8",
                        Operation = "Add",
                        SecondValue = "2",
                        ExpectedResult = "10"            
                    }
                }
            };
        }

        [Fact]
        public void CheckAddition()
        {
            Button threeBtn = mainWindow.Get<Button>(SearchCriteria.ByAutomationId("133"));
            Button twoBtn = mainWindow.Get<Button>(SearchCriteria.ByAutomationId("132"));
            Button plusBtn = mainWindow.Get<Button>(SearchCriteria.ByAutomationId("93"));
            Button equalBtn = mainWindow.Get<Button>(SearchCriteria.ByAutomationId("121"));
            Label resultWindow = mainWindow.Get<Label>(SearchCriteria.ByAutomationId("150"));

            threeBtn.Click();
            plusBtn.Click();
            twoBtn.Click();
            equalBtn.Click();
            Assert.Equal(resultWindow.Text, "5");
        }

        [Theory]
        [MemberData("InputData")]
        public void CheckAdditionDataDriven(string iterationName, CalcDataSet calcData)
        {
            Button firstBtn = mainWindow.Get<Button>(SearchCriteria.ByText(calcData.FirstValue));
            Button secondBtn = mainWindow.Get<Button>(SearchCriteria.ByText(calcData.SecondValue));
            Button operationBtn = mainWindow.Get<Button>(SearchCriteria.ByText(calcData.Operation));
            Button equalBtn = mainWindow.Get<Button>(SearchCriteria.ByAutomationId("121"));
            Label resultWindow = mainWindow.Get<Label>(SearchCriteria.ByAutomationId("150"));

            firstBtn.Click();
            operationBtn.Click();
            secondBtn.Click();
            equalBtn.Click();
            Assert.Equal(resultWindow.Text, calcData.ExpectedResult);
        }

        [Fact]
        public void CheckAdditionPageObject()
        {
            CalculatorWindow mainWindow = new CalculatorWindow(calcApp.GetWindow("Calculator"));
            mainWindow.SetValue("1");
            mainWindow.SetOperation(Operation.Add);
            mainWindow.SetValue("2");
            mainWindow.EqualBtn.Click();
            string actualResult = mainWindow.ReturnResult();
            string expectedResult = "3";
            Assert.Equal(actualResult, expectedResult);
        }

        //[Fact]
        //public void VerifyVersionInAboutWin()
        //{
        //    mainWindow.HelpMenu.Click();
        //    mainWindow.AboutCalculatorMenu.Click();
        //    List<Window> modalWindows = mainWindow.Win.ModalWindows();
        //}
    }
}
