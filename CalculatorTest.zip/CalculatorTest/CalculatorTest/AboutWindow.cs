﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestStack.White;
using TestStack.White.Factory;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems;
using Xunit.Sdk;
using Xunit.Extensions;
using TestStack.White.UIItems.WindowStripControls;

namespace CalculatorTestSuite
{
    public class AboutWindow : BaseWindow
    {
        public override string Name
        {
            get
            {
                return "About Calculator";
            }
        }
        
        public Window AboutWin;
        public Button OKBtn
        {
            get
            {
                return AboutWin.Get<Button>(SearchCriteria.ByAutomationId("1"));
            }
        }
        public Label VersionInformation
        {
            get
            {
                return AboutWin.Get<Label>(SearchCriteria.ByAutomationId("13579"));
            }
        }

        public AboutWindow(Window window) : base(window)
        {
         
        }
    }
}
