﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestStack.White;
using TestStack.White.Factory;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems;
using Xunit.Sdk;
using Xunit.Extensions;
using TestStack.White.UIItems.WindowStripControls;

namespace CalculatorTestSuite
{
    public class CalculatorWindow : BaseWindow
    {
        public CalculatorWindow(Window Win) : base(Win)
        {

        }
        public override string Name
        {
            get
            {
                return "Calculator";
            }
        }
        
        public Button Add
        {
            get
            {
                return Win.Get<Button>(SearchCriteria.ByAutomationId("93"));
            }
        }
        public Button Subtract
        {
            get
            {
                return Win.Get<Button>(SearchCriteria.ByAutomationId("94"));
            }
        }
        public Button Divide
        {
            get
            {
                return Win.Get<Button>(SearchCriteria.ByAutomationId("91"));
            }
        }
        public Button Multiply
        {
            get
            {
                return Win.Get<Button>(SearchCriteria.ByAutomationId("92"));
            }
        }
        public Button EqualBtn
        {
            get
            {
                return Win.Get<Button>(SearchCriteria.ByAutomationId("121"));
            }
        }
        public Label ResultLabel
        {
            get
            {
                return Win.Get<Label>(SearchCriteria.ByAutomationId("150"));
            }
        }
        public Menu HelpMenu
        {
            get 
            {
                return Win.Get<Menu>(SearchCriteria.ByAutomationId("Item 3"));
            }
        }
        public Menu AboutCalculatorMenu
        {
            get
            {
                return Win.Get<Menu>(SearchCriteria.ByAutomationId("Item 302"));
            }
        }        

        public void SetValue(string value)
        {
            Win.Get<Button>(SearchCriteria.ByText(value)).Click();
        }

        public void SetOperation(Operation operation)
        {
            switch (operation)
            {
                case Operation.Add:
                    Add.Click();
                    break;
                case Operation.Subtract:
                    Subtract.Click();
                    break;
                case Operation.Multiply:
                    Multiply.Click();
                    break;
                case Operation.Divide:
                    Divide.Click();
                    break;
            }           
        }

        public string ReturnResult()
        {
            return ResultLabel.Text;
        }
    }

    public enum Operation
    {
        Add,
        Subtract,
        Divide,
        Multiply
    }
}
