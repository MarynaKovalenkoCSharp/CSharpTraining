﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestStack.White;
using TestStack.White.Factory;
using TestStack.White.UIItems.Finders;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems;
using Xunit.Sdk;
using Xunit.Extensions;
using TestStack.White.UIItems.WindowStripControls;

namespace CalculatorTestSuite
{
    abstract public class BaseWindow
    {
        public Window Win;
        public abstract string Name
        {
            get;
        }

        public BaseWindow(Window window)
        {
            if (!window.Title.Equals(Name))
            {
                throw new InvalidWindowException("This window is not valid for testing");
            }
            else
                Win = window;
        }
    }
}
